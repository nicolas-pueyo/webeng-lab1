rootProject.name = "lab1-git-race"
